package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.ServiceMen;
import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.repo.ServiceMenDaoJpa;
import com.example.demo.repo.UserDaoJpa;
import com.example.demo.service.UserDaoImpl;

@Controller
public class LoginController {
	@Autowired
	private UserDetails user;

	@Autowired
	private ServiceMen serviceMen;

	
	@Autowired
	private UserDaoImpl userDaoImpl;
	@Autowired
	private User loginUser;

	@Autowired
	private UserDaoJpa userDaoJpa;

	@Autowired
	private ServiceMenDaoJpa serviceMenDaoJpa;

	@GetMapping(path = "/index")
	public String loginUser(Model model) {
		model.addAttribute("command", user);
		return "index";

	}

	@PostMapping("/index")
	public String loginUser(@Valid @ModelAttribute("command") User loginUser,Model model, BindingResult result) {
		
		
		String nextPage = "failure";
		 UserDetails user=userDaoJpa.findByUserNameAndUserPassword(loginUser.getUserName(), loginUser.getUserPassword());
		 if(user != null)
		 {
			 
			 if(user.role.equals("admin")){
				 System.out.println(user.role);
				 return "adminServices";
				 }
			 else
				 return "userPage";
		 }
		 return "failure";
	}
	

	@GetMapping(path = "/Registeration")
	public String registerUser(Model model) {
		model.addAttribute("command", user);
		return "Registeration";
	}

	@PostMapping("/Registeration")
	public String registerUser(@Valid @ModelAttribute("command") UserDetails user, BindingResult result) {
		String nextPage = "index";
		userDaoJpa.save(user);
		return nextPage;
	}

}
