package com.example.demo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.repo.ServiceMenDaoJpa;
import com.example.demo.repo.UserDaoJpa;
import com.example.demo.entity.ServiceMen;
import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.service.ServiceMenDaoImpl;
import com.example.demo.service.UserDaoImpl;

@Controller
public class ServiceMenController {

	@Autowired
	private ServiceMen serviceMen;

	@Autowired
	private ServiceMenDaoImpl serviceMenDaoImpl;

	@Autowired
	private ServiceMenDaoJpa serviceMenDaoJpa;

	@GetMapping(path = "/addServiceMen")
	public String addServiceMen(Model model) {
		model.addAttribute("command", serviceMen);
		System.out.println("In get");
		return "addServiceMen";
	}

	@PostMapping("/addServiceMen")
	public String addServiceMen(@Valid @ModelAttribute("command") ServiceMen serviceMen, BindingResult result) {
		String nextPage = "success";
		System.out.println("In post");
		serviceMenDaoJpa.save(serviceMen);
		System.out.println("In after");
		return "adminServices";
	}

	
	@GetMapping(path = "/removeServiceMen")
	public String removeServiceMen(@RequestParam String id, Model model) {
		System.out.println("deleting String" + id);
		
		int serviceMenId = Integer.parseInt(id);
		System.out.println("deleting");
		serviceMenDaoJpa.deleteById(serviceMenId);
		List<ServiceMen> list = serviceMenDaoJpa.findAll();
		model.addAttribute("list", list);
		return "ViewAllServiceMenForAdmin";
	}

	@PostMapping("/removeServiceMen")
	public String removeServiceMen(@Valid @ModelAttribute("command") ServiceMen serviceMen, BindingResult result) {
		String nextPage = "success";
		System.out.println("In post");
		serviceMenDaoImpl.remove(serviceMen);
		System.out.println("In after");
		return "ViewAllServiceMenForAdmin";
	}

	@GetMapping(path = "/updateServiceMen/{id}")
	public String updateServiceMen(@PathVariable("id") int id,Model model) {
		System.out.println(id);
		
		Optional<ServiceMen> service=serviceMenDaoJpa.findById(id);
		System.out.println(service.get());
		ServiceMen serviceman=service.get();
		System.out.println(serviceman.getServiceMenCity());
//	
//		System.out.println(serviceman);
//		Optional<ServiceMen> value = serviceMenDaoJpa.findById(id);
//		ArrayList<ServiceMen>list = new ArrayList<ServiceMen>();
//		list.add(value.get());
		model.addAttribute("list", serviceman);
		return "updateServiceMen";
	}
	@PostMapping("/updateServiceMen")
	public String updateServiceMen(@Valid @ModelAttribute("command") ServiceMen serviceMen, BindingResult result) {
		String nextPage = "success";
		System.out.println("In post");
		serviceMenDaoImpl.update(serviceMen);
		System.out.println("In after");
		return "adminServices";
	}
	
	
	@GetMapping(path = "/ViewAllServiceMen")
	public String getAllServiceMen(Model model) {
		List<ServiceMen> list = serviceMenDaoJpa.findAll();
		model.addAttribute("list", list);
		return "ViewAllServiceMen";
	}

	@GetMapping(path = "/ViewAllServiceMenForAdmin")
	public String getAllServiceMenForAdmin(Model model) {
		List<ServiceMen> list = serviceMenDaoJpa.findAll();
		model.addAttribute("list", list);
		return "ViewAllServiceMenForAdmin";
	}

	@RequestMapping(value = "/getServiceMenByCity", method = RequestMethod.POST)
	public String getServiceMenByCity(@RequestParam("city") String city, Model model) {

		List<Map<String, Object>> serviceMenDetails = serviceMenDaoImpl.getServiceMenByCity(city);
		model.addAttribute("list", serviceMenDetails);
		if (serviceMenDetails.size() == 0) {
			return "failure";
		} else {
			System.out.println(serviceMenDetails);
			return "ViewAllServiceMen";
		}
	}

	@RequestMapping(value = "/getServiceMenByCategory", method = RequestMethod.POST)
	public String getServiceMenByCategory(@RequestParam("category") String category, Model model) {

		List<Map<String, Object>> serviceMenDetails = serviceMenDaoImpl.getServiceMenByCategory(category);
		model.addAttribute("list", serviceMenDetails);
		if (serviceMenDetails.size() == 0) {
			return "failure";
		} else {
			System.out.println(serviceMenDetails);
			return "ViewAllServiceMen";
		}
	}

}
