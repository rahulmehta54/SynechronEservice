package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ServiceMen")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ServiceMen {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	public int serviceMenId;
	public String serviceCategory;
	
	public long serviceMenMobileNumber;
	public String serviceMenCity;
	public double serviceMenExperiance;
	public double serviceMenInspectionRate;
	public int getServiceMenId() {
		return serviceMenId;
	}
	public void setServiceMenId(int serviceMenId) {
		this.serviceMenId = serviceMenId;
	}
	public String getServiceCategory() {
		return serviceCategory;
	}
	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}
	public long getServiceMenMobileNumber() {
		return serviceMenMobileNumber;
	}
	public void setServiceMenMobileNumber(long serviceMenMobileNumber) {
		this.serviceMenMobileNumber = serviceMenMobileNumber;
	}
	public String getServiceMenCity() {
		return serviceMenCity;
	}
	public void setServiceMenCity(String serviceMenCity) {
		this.serviceMenCity = serviceMenCity;
	}
	public double getServiceMenExperiance() {
		return serviceMenExperiance;
	}
	public void setServiceMenExperiance(double serviceMenExperiance) {
		this.serviceMenExperiance = serviceMenExperiance;
	}
	public double getServiceMenInspectionRate() {
		return serviceMenInspectionRate;
	}
	public void setServiceMenInspectionRate(double serviceMenInspectionRate) {
		this.serviceMenInspectionRate = serviceMenInspectionRate;
	}
	public ServiceMen() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ServiceMen(int serviceMenId, String serviceCategory, long serviceMenMobileNumber, String serviceMenCity,
			double serviceMenExperiance, double serviceMenInspectionRate) {
		super();
		this.serviceMenId = serviceMenId;
		this.serviceCategory = serviceCategory;
		this.serviceMenMobileNumber = serviceMenMobileNumber;
		this.serviceMenCity = serviceMenCity;
		this.serviceMenExperiance = serviceMenExperiance;
		this.serviceMenInspectionRate = serviceMenInspectionRate;
	}
	
	
	
}