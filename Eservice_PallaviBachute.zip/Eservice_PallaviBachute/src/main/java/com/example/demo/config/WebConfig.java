package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Orders;
import com.example.demo.entity.ServiceMen;
import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.service.ServiceMenDaoImpl;
import com.example.demo.service.UserDaoImpl;

@Configuration
public class WebConfig {
	@Bean
	public ModelAndView mdView() {
		return new ModelAndView();
	}
	@Bean
	public UserDetails userdetail(){
		return new UserDetails();
	}
	@Bean
	public ServiceMen servicemen() {
		return new ServiceMen();
	}
	@Bean
	public Orders orders() {
		return new Orders();
	}
	@Bean
	public User user() {
		return new User();
	}
	@Bean
	public UserDaoImpl  userDaoImpl() {
		return new UserDaoImpl();
	}
	@Bean
	public ServiceMenDaoImpl  serviceMenDaoImpl() {
		return new ServiceMenDaoImpl();
	}
	
}
