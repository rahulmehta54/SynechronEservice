
  package com.example.demo.controller;
  
  import org.springframework.beans.factory.annotation.Autowired; import
  org.springframework.stereotype.Controller; import
  org.springframework.web.bind.annotation.GetMapping; import
  org.springframework.web.servlet.ModelAndView;
  
  import lombok.Setter;
  
  @Controller
  
  @Setter public class WelcomeControllers 
  {
  
	  @Autowired private ModelAndView mdlView;
  
	  @GetMapping("/") 
	  public ModelAndView init() { 
		  mdlView.setViewName("welcome");
		  mdlView.addObject("mainHeading","sai Travel Agency");
  
		  return mdlView; 
	  } 
  }
 