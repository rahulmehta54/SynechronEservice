package com.example.demo.service;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.repo.DaoServices;


public class UserDaoImpl implements DaoServices{
	@Autowired
	private JdbcTemplate template;

	@Override
	public  List<Map<String,Object>> findUserByUserNamePassword(User user) {
		// TODO Auto-generated method stub	
		String userName = user.getUserName();
		String password = user.getUserPassword();
		String sql ="select * from UserDetails where UserName='"+userName+"'and userPassword='"+password+"'";
		List<Map<String, Object>> result = this.template.queryForList(sql);
		System.out.println("user name dao :"+ result.toString());
		System.out.println("size :"+ result.size());
		return result;
		
	}

	/*
	 * @Override public List<Map<String,Object>> findAll() { String sql =
	 * "select * from Tour"; return this.template.queryForList(sql); }
	 */

}
