package com.example.demo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.persistence.Id;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.example.demo.entity.ServiceMen;
import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.repo.DaoServices;


public class ServiceMenDaoImpl {
	@Autowired
	private JdbcTemplate template;

	public int update(ServiceMen s) {
		String sql1 = "update ServiceMen set"
				+ "ServiceCategory=?, ServiceMenCity=?, ServiceMenExperiance=?, ServiceMenInspectionRate=? where serviceMenMobileNumber =? where serviceMenId=?";
		return this.template.update(sql1, s.serviceCategory, s.serviceMenCity, s.serviceMenExperiance,
				s.serviceMenInspectionRate, s.serviceMenMobileNumber);
	}

	public long remove(ServiceMen s) {
		String sql2 = "delete from ServiceMen where serviceMenId =?";

		return this.template.update(sql2, s.serviceMenId);

	}

	
	 

	public List<Map<String, Object>> getServiceMenByCity(String city) {
		// TODO Auto-generated method stub

		String sql = "select * from ServiceMen where serviceMenCity='" + city + "'";
		List<Map<String, Object>> result = this.template.queryForList(sql);
		return result;
	}

	public List<Map<String, Object>> getServiceMenByCategory(String category) {
		// TODO Auto-generated method stub
		String sql = "select * from ServiceMen where serviceCategory='" + category + "'";
		  List<Map<String, Object>> result = this.template.queryForList(sql);		 
		return result;
	}

	public List<Map<String, Object>> findAll() {
		// TODO Auto-generated method stub
		String sql= "select * from ServiceMen";
		return this.template.queryForList(sql);
		
	}

}
