package com.example.demo.repo;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.ServiceMen;
@Repository
public interface ServiceMenDao{
	int update(ServiceMen s);
	long remove(ServiceMen s);
	List<Map<String, Object>> getServiceMenByCity(String city);
	List<Map<String, Object>> getServiceMenByCategory(String category);
	List<Map<String, Object>> findAll();
	
}
